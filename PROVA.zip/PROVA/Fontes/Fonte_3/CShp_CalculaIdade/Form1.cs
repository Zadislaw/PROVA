﻿using System;
using System.Windows.Forms;

namespace CShp_CalculaIdade
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnCalcularIdade_Click(object sender, EventArgs e)
        {
            if (dtpNascimento.Value < DateTime.Now)
            {
                DateTime DataNascimento = dtpNascimento.Value;
                DateTime DataAtual = DateTime.Now;
                int resultado = CalculaIdade(dtpNascimento.Value);
                lblIdade.Text = $" {resultado} anos";
                if (DataNascimento.Month == DataAtual.Month & DataNascimento.Day == DataAtual.Day) {
                    MessageBox.Show(Convert.ToString("Feliz Aniversário!!!"));
                      }
            }
            else
            {
               MessageBox.Show("Data inválida");
            }
        }

        private static int CalculaIdade(DateTime dataNascimento)
        {
                int idade = DateTime.Now.Year - dataNascimento.Year;
                if (DateTime.Now.DayOfYear < dataNascimento.DayOfYear)
                {
                    idade = idade - 1;
                }
                return idade;
        }

        private void btnCalculaIdadeMaisPrecisa_Click(object sender, EventArgs e)
        {
            DateTime DataNascimento = dtpNascimento.Value;
            DateTime DataAtual = DateTime.Now;
            int Anos = new DateTime(DateTime.Now.Subtract(DataNascimento).Ticks).Year - 1;
            DateTime AnosTranscorridos = DataNascimento.AddYears(Anos);
            int Meses = 0;
            for (int i = 1; i <= 12; i++)
            {
                if (AnosTranscorridos.AddMonths(i) == DataAtual)
                {
                    Meses = i;
                    break;
                }
                else if (AnosTranscorridos.AddMonths(i) >= DataAtual)
                {
                    Meses = i - 1;
                    break;
                }
            }
            int Dias = DataAtual.Subtract(AnosTranscorridos.AddMonths(Meses)).Days;
            int Horas = DataAtual.Subtract(AnosTranscorridos).Hours;
            int Minutos = DataAtual.Subtract(AnosTranscorridos).Minutes;
            int Segundos = DataAtual.Subtract(AnosTranscorridos).Seconds;

            lblIdade.Text = $"{Anos} anos {Meses} Meses {Dias} dias {Horas} horas " +
                            $"{Minutos} minutos {Segundos} segundos";

            if (DataNascimento.Month == DataAtual.Month & DataNascimento.Day == DataAtual.Day)
            {
                MessageBox.Show(Convert.ToString("Feliz Aniversário!!!"));
            }
        }
    }
}
