﻿namespace CShp_CalculaIdade
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtpNascimento = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCalcularIdade = new System.Windows.Forms.Button();
            this.lblIdade = new System.Windows.Forms.Label();
            this.btnCalculaIdadeMaisPrecisa = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dtpNascimento
            // 
            this.dtpNascimento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNascimento.Location = new System.Drawing.Point(28, 57);
            this.dtpNascimento.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dtpNascimento.Name = "dtpNascimento";
            this.dtpNascimento.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dtpNascimento.Size = new System.Drawing.Size(438, 29);
            this.dtpNascimento.TabIndex = 0;
            this.dtpNascimento.Value = new System.DateTime(1968, 12, 10, 0, 0, 0, 0);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 26);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "Informe a data de nascimento";
            // 
            // btnCalcularIdade
            // 
            this.btnCalcularIdade.Location = new System.Drawing.Point(28, 96);
            this.btnCalcularIdade.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCalcularIdade.Name = "btnCalcularIdade";
            this.btnCalcularIdade.Size = new System.Drawing.Size(182, 67);
            this.btnCalcularIdade.TabIndex = 2;
            this.btnCalcularIdade.Text = "Calcular Idade em anos";
            this.btnCalcularIdade.UseVisualStyleBackColor = true;
            this.btnCalcularIdade.Click += new System.EventHandler(this.btnCalcularIdade_Click);
            // 
            // lblIdade
            // 
            this.lblIdade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblIdade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblIdade.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdade.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblIdade.Location = new System.Drawing.Point(28, 182);
            this.lblIdade.Name = "lblIdade";
            this.lblIdade.Size = new System.Drawing.Size(438, 92);
            this.lblIdade.TabIndex = 3;
            // 
            // btnCalculaIdadeMaisPrecisa
            // 
            this.btnCalculaIdadeMaisPrecisa.Location = new System.Drawing.Point(231, 96);
            this.btnCalculaIdadeMaisPrecisa.Name = "btnCalculaIdadeMaisPrecisa";
            this.btnCalculaIdadeMaisPrecisa.Size = new System.Drawing.Size(235, 67);
            this.btnCalculaIdadeMaisPrecisa.TabIndex = 4;
            this.btnCalculaIdadeMaisPrecisa.Text = "Calcula idade em anos, meses, dias, minutos e segundos";
            this.btnCalculaIdadeMaisPrecisa.UseVisualStyleBackColor = true;
            this.btnCalculaIdadeMaisPrecisa.Click += new System.EventHandler(this.btnCalculaIdadeMaisPrecisa_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(499, 295);
            this.Controls.Add(this.btnCalculaIdadeMaisPrecisa);
            this.Controls.Add(this.lblIdade);
            this.Controls.Add(this.btnCalcularIdade);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpNascimento);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calcular Idade";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtpNascimento;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCalcularIdade;
        private System.Windows.Forms.Label lblIdade;
        private System.Windows.Forms.Button btnCalculaIdadeMaisPrecisa;
    }
}

