﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoExemploSQLite
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            return;
        }

        private void buscarButton_Click(object sender, EventArgs e)
        {
            var clientes = new ClienteDAO().Listar();
            quantidadeLabel.Text = "Registros: " + clientes.Count().ToString();
            dataGridView1.DataSource = clientes;
        }

        private void fecharButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void novoButton_Click(object sender, EventArgs e)
        {
            //abre a tela de cadastro
            new Form2().ShowDialog();

            //atualiza o grid
            buscarButton.PerformClick();
        }

        private void alterarButton_Click(object sender, EventArgs e)
        {
            int id = 0;
            try { id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value); }
            catch
            {
                MessageBox.Show("Erro ao selecionar o registro");
                return;
            }

            //abre a tela de alteração
            new Form2(id).ShowDialog();

            //atualiza o grid
            buscarButton.PerformClick();
        }

        private void excluirButton_Click(object sender, EventArgs e)
        {
            int id = 0;
            try { id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value); }
            catch
            {
                MessageBox.Show("Erro ao selecionar o registro");
                return;
            }

            //exclui
            if (MessageBox.Show(ProductName, "Confirma Exclusão?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                new ClienteDAO().Excluir(id);
            }

            //atualiza o grid
            buscarButton.PerformClick();
        }
    }
}
