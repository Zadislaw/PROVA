﻿using System;
using System.Windows.Forms;

namespace ProjetoExemploSQLite
{
    public partial class Form2 : Form
    {
        Cliente cliente = null;
        public Form2()
        {
            InitializeComponent();

            this.Text = "Inclusão de Novo Cliente";
            idTextBox.Text = "Automático";
            idTextBox.ReadOnly = true;
            nomeTextBox.Focus();

            cliente = new Cliente();
        }

        public Form2(int idCliente)
        {
            InitializeComponent();

            this.Text = "Alteração de Cliente existente";
            cliente = new ClienteDAO().Buscar(idCliente);
            if (cliente == null)
            {
                this.Text = "Inclusão de Novo Cliente";
                idTextBox.Text = "Automático";
                idTextBox.ReadOnly = true;
                nomeTextBox.Focus();

                cliente = new Cliente();
            }
            else
            {
                idTextBox.Text = cliente.ID.ToString();
                idTextBox.ReadOnly = true;
                nomeTextBox.Text = cliente.Nome;
                telefoneTextBox.Text = cliente.Username;
                EmailTextBox.Text = cliente.Email;
                textBox1.Text = cliente.Senha;
                dateTimePicker1.Value = cliente.Dtnascimento;

            }
        }

        private void fecharButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void salvarButton_Click(object sender, EventArgs e)
        {
            cliente.Nome = nomeTextBox.Text.Trim();
            cliente.Username = telefoneTextBox.Text.Trim();
            cliente.Email = EmailTextBox.Text.Trim();
            cliente.Senha = textBox1.Text.Trim();
//            cliente.Dtnascimento = dateTimePicker1.Value;

            if (cliente.ID == 0)
            {
                var resultado = new ClienteDAO().Inserir(cliente);
                if (resultado == 0)
                    MessageBox.Show("Erro ao inserir!");
                else
                {
                    MessageBox.Show("Você foi cadastrado com sucesso!");
                    Close();
                }
            }
            else
            {
                var resultado = new ClienteDAO().Alterar(cliente);
                if (resultado == 0)
                    MessageBox.Show("Erro ao alterar!");
                else
                {
                    MessageBox.Show("Alterado com sucesso!");
                    Close();
                }
            }
        }

        private void EmailTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}