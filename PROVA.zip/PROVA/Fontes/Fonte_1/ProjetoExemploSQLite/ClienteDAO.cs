﻿using Dapper;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ProjetoExemploSQLite
{
    public class ClienteDAO : Conexao
    {
        public void CriarTabela()
        {
            using (var banco = Banco)
            {
                banco.Open();
                banco.Execute(
                    @"ALTER TABLE  Usuarios (
                        Idusuario INTEGER PRIMARY KEY AUTOINCREMENT,                   
                        Nome varchar(50) not null,
                        Username varchar(50) null,
                        Senha varchar(50)  null
                        Dtnascimento date null,
                        Email varchar(50) null)");
            }
        }

        public List<Cliente> Listar()
        {
            if (!File.Exists(Arquivo))
                CriarTabela();

            using (var banco = Banco)
            {
                banco.Open();
                return banco.Query<Cliente>(@"SELECT * FROM Usuarios ORDER BY Nome").ToList();
            }
        }
        public Cliente Buscar(int id)
        {
            if (!File.Exists(Arquivo))
                CriarTabela();

            using (var banco = Banco)
            {
                banco.Open();
                return banco.Query<Cliente>(@"SELECT * FROM Usuarios WHERE Id = @pId",
                    new { pId = id }).SingleOrDefault();
            }
        }



        public int Inserir(Cliente cliente)
        {
            if (!File.Exists(Arquivo))
                CriarTabela();

            using (var banco = Banco)
            {
                banco.Open();
                cliente.ID = banco.Query<int>(
                    @"INSERT INTO Usuarios 
                    (Nome, Username, Email, Senha ) VALUES (@Nome, @Username, @Email, @Senha ); 
                    select last_insert_rowid()", cliente).First();
            }

            return cliente.ID;
        }

        public int Alterar(Cliente cliente)
        {
            if (!File.Exists(Arquivo))
                CriarTabela();

            var registrosAlterados = 0;
            using (var banco = Banco)
            {
                banco.Open();
                registrosAlterados = banco.Execute(
                    @"UPDATE Usuarios SET 
                      Nome = @Nome, Username = @Username, Email = @Email, Senha = @Senha, Dtnascimento = @Dtnascimento 
                      WHERE ID = @ID", cliente);
            }

            return registrosAlterados;
        }

        public int Excluir(int idCliente)
        {
            if (!File.Exists(Arquivo))
                CriarTabela();

            var registrosExcluidos = 0;
            using (var banco = Banco)
            {
                banco.Open();
                registrosExcluidos = banco.Execute(
                    @"DELETE FROM Usuarios  
                      WHERE ID = @pId", new { pId = idCliente });
            }

            return registrosExcluidos;
        }

    }
}