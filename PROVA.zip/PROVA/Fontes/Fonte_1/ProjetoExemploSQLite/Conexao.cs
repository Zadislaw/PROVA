﻿using System;
using System.Data.SQLite;

namespace ProjetoExemploSQLite
{
    public class Conexao
    {
        public string Arquivo
        {
            get
            {
                //pega o caminho em que o programa está rodando
                return Environment.CurrentDirectory + "\\exerc1.s3db";
            }
        }

        public SQLiteConnection Banco
        {
            get
            {
                return new SQLiteConnection("Data Source=" + Arquivo);
            }
        }
    }
}