﻿using System;

namespace ProjetoExemploSQLite
{
    public class Cliente
    {
        internal readonly DateTime Dtnascimento;

        public int ID { get; set; }
        public string Nome { get; set; }
        public string Username { get; set; } //Username
        public string Email { get; set; } //Cidade

        public string Senha { get; set; }
    }
}
