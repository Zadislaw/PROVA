﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace CShp_CalculaIdade
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btn_Click(object sender, EventArgs e)
        {


            string texto = txt.Text;
            int length = texto.Length;
            if (length <= 3)
            {
                MessageBox.Show("Tem que digitar mais de tres caracteres!");
            }
            else
            {

                string textoInvertido = new string(texto.Reverse().ToArray());
                lbl.Text = $"Texto Invertido: {textoInvertido}";
                if (checkPalindrome(texto))
                {
                    MessageBox.Show("É um palíndromo!!!");
                }

            }

        }
    }
}
