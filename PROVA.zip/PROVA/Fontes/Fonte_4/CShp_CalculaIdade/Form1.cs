﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;
using pnyx.net.fluent;
using pnyx.net.impl;
using pnyx.net.util;
using pnyx.net.impl.sed;






namespace CShp_CalculaIdade
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btn_Click(object sender, EventArgs e)
        {
            float valorE = 0;
            float valorD = 0;

            string resultado = this.GetResponseString("text");
            string json = resultado;



            JObject rss = JObject.Parse(json);

            string rssBid = (string)rss["USDBRL"]["high"];

            valorE = (float)Convert.ToDouble(rssBid);

            var texto = txt.Text;
 //           float valorD;
            if (float.TryParse(texto.ToString(), out valorD))
            {
                valorE = valorE / 1000;
                float cotacao = valorE * valorD;

                lbl.Text = $"R$ {cotacao}";
            }
            else
            {
                MessageBox.Show("Digite um valor numérico válido!");
            }




        }


    }

}



